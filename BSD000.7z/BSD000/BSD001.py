print(5) # Типы данных
print(type(5))
print(5+5)
print(5-5)
print(5*5)
print(5/5)
print(5//5) # // целочисленное деление, / - деление
print(5%5)
print(5**5)
print(2.0)
print(type(2.0))
print(2.0+2.0)
print(2.0+2) # Строки
print('Hello, world!') # - без ковычек выводит ошибку print(Hello, world!)
print(type('Hello, world!')) # string - строка
print('Hello,' + 'world!')
print('1'+'1') # concatenate, разные типы данных не складываются print('1'+1). # Логический тип данных.
print(True, False) # они указывают на истину или ложность того, или иного выражения
print(type(True), type(False)) # boolen
print(5>10)
print(5>10, 10>5)
print(5==5) # >,<,>=,>=,== - равенство обьектов, != - не равенство обьектов.
print(5 != 5)
print(5!= 5 and 5<10) # команды and - и, or - или.
print(5!= 5 or 5<10) # Изменения типа данных.
print(int('5'))
print(type(int('5'))) # логично что текст  перевести в числовой тип данных мы не можем.