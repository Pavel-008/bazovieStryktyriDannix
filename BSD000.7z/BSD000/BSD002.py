print(12+89-1)
print(9**0.5*5) # 1st program
print(9.99>9.98 and 1000!=1000.1) # 2st program
print((2*2+2) == (2*(2+2))) # 3st program (print((int('123.456'))*10) - ошибка)
print('123' + '.456') # 4st program (print((int('123.456'))) - ошибка)
print(123.456*10)
print(1234.56-1230.56)
print(int('4'))
